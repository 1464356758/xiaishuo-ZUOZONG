import test from 'node:test';
import assert from 'node:assert/strict';
import {GitHubClient,HubError,dayInShanghai,validDay,safeBranch,blankRegistry,validateRegistry,validateChatURL,encodeLocator,decodeLocator,sha256,loadBook,inspectBook,inspectRegistry,registryFingerprint,reportState,saveRegistry,STATUS,validateReaderURL,validateLocalBackup,randomId,suggestedChapter,inspectExecution,writingPrompt} from '../dist/hub-core.mjs';
import {SnapshotClient,reportBundle,preserveValidStates} from '../../tools/check_updates.mjs';
import {repairPrompt} from '../dist/hub-core.mjs';
const now=new Date('2026-10-26T12:00:00Z'),commit='a'.repeat(40);
const entry=()=>({id:'entry_test',book_id:'synthetic_test_book',title:'合成机制测试',repository_url:'https://github.com/example/synthetic-test',branch:'main',enabled:true,expected_time:'09:00',grace_minutes:60,effective_from:'2026-10-25',baseline:{chapter_count:0,commit,captured_at:'2026-10-25T12:00:00Z'}});
const registry=b=>({...blankRegistry(),books:b||[entry()]});
const enc=x=>JSON.stringify(x,null,2)+'\n';
async function fixture(){
  const body='仅用于自动化机制测试，不是正式小说。',bodyHash=await sha256(body),record={chapter:1,text_sha256:bodyHash};
  const recordText=enc(record),recordHash=await sha256(recordText),release={book_id:'synthetic_test_book',chapter:1,text_sha256:bodyHash,record_sha256:recordHash,decision:'release',read_full_text:true,blocking_issues:[]};
  const releaseText=enc(release),releaseHash=await sha256(releaseText),bodyPath='chapters/CH001_'+bodyHash+'.txt',recordPath='records/CH001_'+recordHash+'.json',releasePath='releases/CH001_'+releaseHash+'.json';
  const state={book_id:'synthetic_test_book',revision:4,chapters:{'1':{title:'合成测试',text_path:bodyPath,text_sha256:bodyHash,record_path:recordPath,record_sha256:recordHash,adopted_at:'2026-10-26T02:20:00Z'}},needs_revalidation:[],serialization:{enabled:true,frozen:{'1':{text_sha256:bodyHash,record_sha256:recordHash}},gates:{'1':{used:true,path:releasePath,sha256:releaseHash}}}};
  const stateText=enc(state),manifest={schema_version:1,initialized:true,book:{id:state.book_id,title:'合成机制测试'},source:{repository_url:entry().repository_url,state_sha256:await sha256(stateText)},progress:{adopted_chapters:1,actual_han:20,target_han:900000,target_chapters:100},task:{phase:'WAITING_NEXT'},chapters:[{number:1,title:'合成测试',han_count:20,sha256:bodyHash,text_path:'book/'+bodyPath,frozen:true}]};
  const receipt={schema_version:1,type:'novel-daily-completion-v1',status:'completed',book_id:state.book_id,run_id:'test_run_12345',work_id:state.book_id+':2026-10-26:1',start_date:'2026-10-26',date:'2026-10-26',started_at:'2026-10-26T02:00:00Z',completed_at:state.chapters['1'].adopted_at,chapter:1,baseline_count:0,baseline_fingerprint:await sha256('[]'),body_path:bodyPath,body_sha256:bodyHash,record_path:recordPath,record_sha256:recordHash,release_path:releasePath,release_sha256:releaseHash};
  const files={'online/index.json':{text:enc(manifest)},'book/state.json':{text:stateText},['book/'+bodyPath]:{text:body},['book/'+recordPath]:{text:recordText},['book/'+releasePath]:{text:releaseText},'book/daily/2026-10-26.json':{text:enc(receipt)},'book/daily/active.json':{missing:true}};
  const source={repository_url:entry().repository_url,branch:'main',commit,committed_at:'2026-10-26T03:00:00Z',files};
  return {state,manifest,receipt,files,source,client:()=>new SnapshotClient(entry(),source)};
}
function writeJSON(f,path,value){f.files[path]={text:enc(value)};}
test('Shanghai boundaries use local day instead of UTC day',()=>{assert.equal(dayInShanghai('2026-10-25T16:00:00Z'),'2026-10-26');assert.equal(dayInShanghai('2026-10-25T15:59:59Z'),'2026-10-25');assert.equal(validDay('2026-02-31'),false);});
test('branch and chat URL reject unsafe values',()=>{assert.throws(()=>safeBranch('../main'));assert.throws(()=>safeBranch('a//b'));assert.throws(()=>validateChatURL('javascript:alert(1)'));assert.throws(()=>validateChatURL('https://chatgpt.com.evil.test/c/1'));assert.match(validateChatURL('https://chatgpt.com/c/test'),/chatgpt.com/);});
test('registry whitelist excludes tokens and retains validated cloud chat URLs',()=>{const input=registry();input.token='TEST_ONLY';input.books[0].chat_url='https://chatgpt.com/c/test';assert.equal(JSON.stringify(validateRegistry(input)).includes('TEST_ONLY'),false);assert.equal(validateRegistry(input).books[0].chat_url,'https://chatgpt.com/c/test');});
test('registry rejects duplicate repo and duplicated book identity',()=>{const a=entry(),b={...entry(),id:'other'};assert.throws(()=>validateRegistry(registry([a,b])));b.repository_url='https://github.com/example/another';assert.throws(()=>validateRegistry(registry([a,b])));});
test('registry rejects invalid dates, timing and false booleans',()=>{for(const patch of [{effective_from:'2026-02-30'},{expected_time:'25:00'},{enabled:'yes'},{grace_minutes:-1}])assert.throws(()=>validateRegistry(registry([{...entry(),...patch}])));});
test('locator round trip preserves repo branch and identity without credentials',async()=>{const code=await encodeLocator({...entry(),branch:'feature/novel'});assert.ok(code.startsWith('NX1.'));assert.deepEqual(await decodeLocator(code),{repository_url:entry().repository_url,branch:'feature/novel',book_id:entry().book_id});});
test('locator rejects corruption and invalid version',async()=>{const code=await encodeLocator(entry());await assert.rejects(decodeLocator(code.slice(0,-1)+(code.endsWith('0')?'1':'0')));await assert.rejects(decodeLocator('https://github.com/example/test'));});
test('valid daily update verifies actual body record release and frozen pins',async()=>{const f=await fixture(),r=await inspectBook(entry(),{client:f.client(),now});assert.equal(r.status,'updated');assert.equal(r.evidence.chapter,1);});
test('paused and not yet enrolled novels cause no network requests',async()=>{const client={snapshot(){throw new Error('must not fetch');}};assert.equal((await inspectBook({...entry(),enabled:false},{client,now})).status,'paused');assert.equal((await inspectBook({...entry(),effective_from:'2026-10-27'},{client,now})).status,'not_due');});
test('absent receipt after deadline is missing, even if the commit is new',async()=>{const f=await fixture();f.files['book/daily/2026-10-26.json']={missing:true};assert.equal((await inspectBook(entry(),{client:f.client(),now})).status,'missing');});
test('before due time is not a missing update',async()=>{const f=await fixture();f.files['book/daily/2026-10-26.json']={missing:true};assert.equal((await inspectBook({...entry(),expected_time:'23:00'},{client:f.client(),now})).status,'not_due');});
test('yesterday completion cannot be relabeled as today',async()=>{const f=await fixture();f.receipt.completed_at='2026-10-25T13:00:00Z';writeJSON(f,'book/daily/2026-10-26.json',f.receipt);assert.equal((await inspectBook(entry(),{client:f.client(),now})).status,'unknown');});
test('completion timestamp must match adoption timestamp',async()=>{const f=await fixture();f.receipt.completed_at='2026-10-26T02:30:00Z';writeJSON(f,'book/daily/2026-10-26.json',f.receipt);assert.equal((await inspectBook(entry(),{client:f.client(),now})).status,'unknown');});
test('a wrong run binding is rejected',async()=>{const f=await fixture();f.receipt.work_id+='another';writeJSON(f,'book/daily/2026-10-26.json',f.receipt);assert.equal((await inspectBook(entry(),{client:f.client(),now})).status,'unknown');});
test('body tampering stops verified status',async()=>{const f=await fixture();f.files['book/'+f.receipt.body_path].text+='篡改';const r=await inspectBook(entry(),{client:f.client(),now});assert.equal(r.status,'unknown');assert.equal(r.error_code,'hash_mismatch');});
test('release report tampering stops verified status',async()=>{const f=await fixture();f.files['book/'+f.receipt.release_path].text+=' ';assert.equal((await inspectBook(entry(),{client:f.client(),now})).status,'unknown');});
test('receipt cannot reference a different evidence path',async()=>{const f=await fixture();f.receipt.body_path='../elsewhere';writeJSON(f,'book/daily/2026-10-26.json',f.receipt);assert.equal((await inspectBook(entry(),{client:f.client(),now})).status,'unknown');});
test('stale index is not treated as missing or success',async()=>{const f=await fixture();f.manifest.source.state_sha256='0'.repeat(64);writeJSON(f,'online/index.json',f.manifest);const r=await inspectBook(entry(),{client:f.client(),now});assert.equal(r.status,'unknown');assert.equal(r.error_code,'stale_index');});
test('missing network evidence differs from a collected 404',async()=>{const f=await fixture();delete f.files['book/daily/2026-10-26.json'];const r=await inspectBook(entry(),{client:f.client(),now});assert.equal(r.status,'unknown');assert.equal(r.error_code,'incomplete_snapshot');});
test('active draft is unfinished rather than counted as adopted',async()=>{const f=await fixture();f.files['book/daily/2026-10-26.json']={missing:true};writeJSON(f,'book/daily/active.json',{book_id:entry().book_id,status:'running',chapter:2});assert.equal((await inspectBook(entry(),{client:f.client(),now})).status,'pending');});
test('identity mismatch does not reuse another novel',async()=>{const f=await fixture();assert.equal((await inspectBook({...entry(),book_id:'another_book'},{client:f.client(),now})).status,'unknown');});
test('report freshness binds day and exact registry content',async()=>{const f=await fixture(),reg=registry(),report=await inspectRegistry(reg,{now,clientFactory:f.client});assert.equal((await reportState(report,reg,now)).fresh,true);const changed=registry([{...entry(),enabled:false}]);assert.equal((await reportState(report,changed,now)).fresh,false);assert.equal((await reportState(report,reg,new Date('2026-10-27T12:00:00Z'))).fresh,false);});
test('forged report counts and future timestamps are not green',async()=>{const f=await fixture(),reg=registry(),r=await inspectRegistry(reg,{now,clientFactory:f.client});r.counts.updated=99;assert.equal((await reportState(r,reg,now)).fresh,false);r.counts.updated=1;r.checked_at='2026-10-26T15:00:00Z';assert.equal((await reportState(r,reg,now)).fresh,false);});
test('reports must cover every novel in the matching registry',async()=>{const f=await fixture(),reg=registry(),r=await inspectRegistry(reg,{now,clientFactory:f.client});r.results=[];for(const k of Object.keys(STATUS))r.counts[k]=0;assert.equal((await reportState(r,reg,now)).fresh,false);});
test('failed read retains prior observed chapter count as historical only',()=>{const report={results:[{id:'entry_test',status:'unknown',commit:null,chapters:null}]},previous={schema_version:1,type:'novel-hub-report-v1',date:'2026-10-25',checked_at:'2026-10-25T12:00:00Z',registry_fingerprint:'a'.repeat(64),registry_revision:1,counts:Object.fromEntries(Object.keys(STATUS).map(k=>[k,k==='updated'?1:0])),results:[{id:'entry_test',title:'test',status:'updated',reason:'test',commit,chapters:10,checked_at:'2026-10-25T12:00:00Z'}]};preserveValidStates(report,previous);assert.equal(report.results[0].status,'unknown');assert.equal(report.results[0].last_valid_state.chapters,10);assert.equal(report.results[0].chapters,null);});
test('report bundles preserve history with separate run IDs',async()=>{const f=await fixture(),r=await inspectRegistry(registry(),{now,clientFactory:f.client}),a=reportBundle(r,'run_first_123'),b=reportBundle(r,'run_second_123');assert.ok(a['reports/2026-10-26/run_first_123.json']);assert.ok(b['reports/2026-10-26/run_second_123.json']);assert.equal(Object.keys(a).length,4);assert.throws(()=>reportBundle(r,'../../evil'));});
test('API token stays scoped to management API and never raw downloads',async()=>{const requests=[],client=new GitHubClient('https://github.com/example/manager',{token:'TEST_ONLY_TOKEN',fetcher:async(url,opts)=>{requests.push({url,opts});return new Response(url.includes('raw.githubusercontent.com')?'test':JSON.stringify({private:false}));}});await client.publicInfo();await client.readFile('books.json',commit);assert.equal(requests[0].opts.headers.Authorization,'Bearer TEST_ONLY_TOKEN');assert.equal(requests[1].opts.headers.Authorization,undefined);assert.equal(requests[0].opts.redirect,'error');client.clearToken();await client.publicInfo();assert.equal(requests[2].opts.headers.Authorization,undefined);});
test('request error does not echo a token or server response body',async()=>{const client=new GitHubClient('example/manager',{token:'TEST_ONLY_SECRET',fetcher:async()=>new Response('TEST_ONLY_SECRET',{status:403})});await assert.rejects(client.publicInfo(),e=>!e.message.includes('TEST_ONLY_SECRET'));});
test('changed remote list prevents any write',async()=>{const text=enc(registry()),requests=[],client=new GitHubClient('example/manager',{token:'TEST_ONLY',fetcher:async(url,o)=>{requests.push(o.method);if(url.endsWith('/manager'))return new Response(JSON.stringify({private:false,default_branch:'main'}));if(url.includes('/commits/'))return new Response(JSON.stringify({sha:commit}));return new Response(text);}});await assert.rejects(saveRegistry(client,registry(),{branch:'main',baseFileHash:'0'.repeat(64)}),e=>e.code==='conflict');assert.ok(requests.every(x=>x==='GET'));});
test('write protects base tree, non-force update and verifies returned files',async()=>{
  const requests=[],newHead='c'.repeat(40),tree='d'.repeat(40);let head=commit,body='';
  const client=new GitHubClient('example/manager',{token:'TEST_ONLY',fetcher:async(url,o)=>{requests.push({url,method:o.method,body:o.body?JSON.parse(o.body):null});let data={};if(url.includes('raw.githubusercontent.com'))return new Response(body);if(url.includes('/commits/main'))data={sha:head};else if(url.endsWith('/git/commits/'+commit))data={tree:{sha:tree}};else if(url.endsWith('/git/blobs')){body=JSON.parse(o.body).content;data={sha:'b'.repeat(40)};}else if(url.endsWith('/git/trees'))data={sha:'e'.repeat(40)};else if(url.endsWith('/git/commits'))data={sha:newHead};else if(url.endsWith('/git/refs/heads/main')){head=newHead;data={ref:'refs/heads/main'};}return new Response(JSON.stringify(data));}});
  await client.writeFiles({'books.json':'new verified list\n'},{expectedHead:commit,branch:'main'});
  assert.equal(requests.find(x=>x.url.endsWith('/git/trees')).body.base_tree,tree);assert.deepEqual(requests.find(x=>x.url.endsWith('/git/commits')).body.parents,[commit]);assert.equal(requests.find(x=>x.method==='PATCH').body.force,false);assert.ok(requests.some(x=>x.url.includes('/'+newHead+'/books.json')));
});
test('a race at branch update is surfaced instead of force overwritten',async()=>{const client=new GitHubClient('example/manager',{token:'TEST_ONLY',fetcher:async(url,o)=>{if(o.method==='PATCH')return new Response('{}',{status:422});return new Response(JSON.stringify(url.includes('/commits/main')?{sha:commit}:url.endsWith('/git/commits/'+commit)?{tree:{sha:'b'.repeat(40)}}:{sha:'c'.repeat(40)}));}});await assert.rejects(client.writeFiles({'books.json':'test'},{expectedHead:commit,branch:'main'}),e=>e.code==='conflict');});
test('local backup restore strips credential fields and validates chat and money',()=>{const input={type:'novel-hub-local-backup-v1',registry:registry(),config:{repository_url:'https://github.com/example/management',branch:'main',token:'TEST_SECRET'},chats:{entry_test:'https://chatgpt.com/c/test'},ledger:[],reader_url:'https://example.com/reader.html'};assert.equal(JSON.stringify(validateLocalBackup(input)).includes('TEST_SECRET'),false);input.chats.entry_test='https://evil.example/c/test';assert.throws(()=>validateLocalBackup(input));});
test('reader URL does not allow credentials, queries or non-http schemes',()=>{assert.equal(validateReaderURL('https://example.com/'),'https://example.com/reader.html');for(const v of ['https://user:secret@example.com/reader.html','https://example.com/reader.html?token=secret','ftp://localhost/reader.html'])assert.throws(()=>validateReaderURL(v));assert.match(randomId(),/^[a-f0-9]{32}$/);});
test('copy progress at the last chapter does not jump back to chapter one',()=>{const chapters=[{number:1},{number:2},{number:3}];assert.equal(suggestedChapter(chapters,{chapter:2}).number,3);assert.equal(suggestedChapter(chapters,{chapter:3}).number,3);assert.equal(suggestedChapter(chapters,null).number,1);assert.equal(suggestedChapter([],null),null);});

test('fixed feedback links survive validation while unsafe targets are rejected',()=>{
 const input=registry();input.books[0].feedback_url='https://chatgpt.com/c/task-feedback';
 assert.equal(validateRegistry(input).books[0].feedback_url,input.books[0].feedback_url);
 input.books[0].feedback_url='https://evil.example/c/task';assert.throws(()=>validateRegistry(input));
});
test('writing instructions reuse one task and never claim to set the model or original thread',()=>{
 const prompt=writingPrompt({...entry(),feedback_url:'https://chatgpt.com/c/task-feedback'},'https://github.com/example/manager');
 for(const required of ['已有就复用','recovered_completion','GitHub','最近三章全文','最多3轮','未验证','不承诺一定返回','task-feedback','novel-executor.yml','.automation/request.json','.automation/config.json','controller','单次网络或工具失败不得自行暂停'])assert.ok(prompt.includes(required),required);
});
test('execution verification is optional and proves real completion independent of query plan settings',async()=>{
 const f=await fixture(),r=await inspectExecution({...entry(),enabled:false,effective_from:'2099-01-01'},{now,client:f.client()});
 assert.equal(r.status,'completed');assert.equal(r.chapter,1);assert.equal(r.evidence.run_id,f.receipt.run_id);assert.equal(r.commit,commit);
});
test('execution verification rejects tampered body instead of claiming the task wrote a chapter',async()=>{
 const f=await fixture();f.files['book/'+f.receipt.body_path].text+='篡改';
 assert.equal((await inspectExecution(entry(),{now,client:f.client()})).status,'unknown');
});
test('running execution is explicitly a record, not proof of a live worker',async()=>{
 const f=await fixture();f.files['book/daily/2026-10-26.json']={missing:true};
 writeJSON(f,'book/daily/active.json',{type:'novel-daily-task-v1',book_id:entry().book_id,run_id:'synthetic_run',chapter:2,status:'running'});
 const result=await inspectExecution(entry(),{now,client:f.client()});assert.equal(result.status,'pending');assert.match(result.reason,/不能证明任务仍存活/);
});
test('completed active without its receipt requests recovery rather than a new chapter',async()=>{
 const f=await fixture();f.files['book/daily/2026-10-26.json']={missing:true};
 writeJSON(f,'book/daily/active.json',{type:'novel-daily-task-v1',book_id:entry().book_id,run_id:f.receipt.run_id,chapter:1,status:'completed',completed_at:f.receipt.completed_at});
 const result=await inspectExecution(entry(),{now,client:f.client()});assert.equal(result.status,'unknown');assert.equal(result.error_code,'missing_receipt');
});

test('both readers reject a changed frozen state even when the index hash was rebuilt',async()=>{
 for(const change of [s=>delete s.serialization.frozen['1'],s=>s.serialization.enabled=false,s=>s.serialization.frozen['1'].record_sha256='0'.repeat(64),s=>{delete s.serialization;s.config={serial_mode:true};}]){
  const f=await fixture();change(f.state);writeJSON(f,'book/state.json',f.state);
  f.manifest.source.state_sha256=await sha256(f.files['book/state.json'].text);writeJSON(f,'online/index.json',f.manifest);
  await assert.rejects(loadBook(f.client()),e=>e.code==='invalid_frozen');
 }
});
test('legacy nonserial reading remains available without claiming frozen protection',async()=>{
 const f=await fixture();delete f.state.serialization;writeJSON(f,'book/state.json',f.state);
 f.manifest.source.state_sha256=await sha256(f.files['book/state.json'].text);writeJSON(f,'online/index.json',f.manifest);
 assert.equal((await loadBook(f.client())).manifest.chapters.length,1);
});
test('a maintenance checkpoint is distinguishable from an ordinary blocked job',async()=>{
 const f=await fixture();f.files['book/daily/2026-10-26.json']={missing:true};
 const active={type:'novel-daily-task-v1',book_id:entry().book_id,run_id:'recovery_checkpoint',chapter:2,status:'blocked',operator_recovery:{status:'ready',ready_run_id:'recovery_checkpoint',old_run_id:'revoked_execution',expected_state_sha256:f.manifest.source.state_sha256,grant_sha256:'a'.repeat(64),audit_sha256:'b'.repeat(64)}};
 writeJSON(f,'book/daily/active.json',active);
 const result=await inspectExecution(entry(),{now,client:f.client()});
 assert.equal(result.status,'recovery_ready');assert.equal(result.chapter,2);assert.match(result.reason,/不代表章节已完成/);
 active.operator_recovery.expected_state_sha256='0'.repeat(64);writeJSON(f,'book/daily/active.json',active);
 assert.equal((await inspectExecution(entry(),{now,client:f.client()})).error_code,'invalid_recovery');
});
test('generated daily and repair instructions can consume an authorized maintenance checkpoint',()=>{
 for(const prompt of [writingPrompt(entry(),'example/manager'),repairPrompt(entry())])for(const word of ['operator_recovery.status','operator_revocation','begin','不自行','返修次数'])assert.ok(prompt.includes(word),word);
});
