# 小说参考库与原创写作

本版支持独立GitHub小说库和新书仓库。作者在同一个GPT入口发出「整理小说库」「按这个平台建立教材」「开始新书」「下一章」。GPT执行阅读、拆解、对照练习和写作，Python负责入库、原文定位、版本及引文检查。

## 准备小说库

将《小说参考库初始化包.zip》解压到一个专门的GitHub仓库，把TXT或Markdown原文放入incoming目录。向GPT提供这个仓库链接与《启动小说库.txt》。工具支持UTF-8、带BOM的UTF-16和GB18030文本。章节按标题识别，有前言则另列一个阅读单元；没有章节标题时按文本行分批。阅读序号与原文标题一起显示，原书写的「第一章」可能是阅读序号2。

首次执行以下命令。批量导入按文件名取书名，可为一批书指定共同的平台和题材。单本导入可以补书名和作者。

```bash
python3 tools/novel_library.py --root . init
python3 tools/novel_library.py --root . import --source incoming --platform 七猫 --genre 古代经商 --signed
python3 tools/novel_library.py --root . catalog
```

签约信息先记为作者提供，并保留说明来源。平台、题材、作者等元信息可以通过单本重新导入补充。已签约作品的后期版本用于学写法，能拿到当时送审版本时在来源说明里记清。各平台、男女频、题材及年代分别选择适用样本。

入库产生轻量总目录、每书分章清单和版本固定的原文。重复入库复用同一原文，单本写入受锁保护。批量导入逐本提交，遇到失败时catalog保留已经成功的结果，修好该文件后可以重试。导入后的阅读进度从零开始。

## 实读并建立教材

先用catalog选书，再按原文位置分批读。超出单次阅读预算时工具提示缩小范围。长行可按字符区间读取。

```bash
python3 tools/novel_library.py --root . read --book 实际书籍编号 --chapter 1
python3 tools/novel_library.py --root . read --book 实际书籍编号 --chapter 1 --start-line 1 --end-line 40
python3 tools/novel_library.py --root . read --book 实际书籍编号 --chapter 1 --start-char 0 --end-char 8000
```

行号为该书原文的绝对行号，read返回章节范围。字符区间相对于本次选定的行段，从0起算、左闭右开。当前批次读到哪里和下一段从哪里开始，在工作反馈中写清。跨会话接管时查看catalog中的书签及已完成范围，再回读需要的原文。部分阅读用bookmark记录下一处位置，next-char相对于该一行从0起算，提交后可以接续；完成一段后才登记拆书。

```bash
python3 tools/novel_library.py --root . bookmark --book 实际书籍编号 --chapter 1 --next-line 41 --note "已读到第40行，下一批从第41行开始"
```

按四个层面选择阅读范围。book要求实际读完整本，arc读完整段情节，scene读一场及必要前后文，prose研究具体叙述或对白。一次集中解决一个问题，追问原文怎样做到，避免笼统写「节奏快」「人设好」。

```bash
python3 tools/novel_library.py --root . study-request --book 实际书籍编号 --level arc --from-chapter 1 --to-chapter 3 --out drafts/开篇拆解.json
# GPT实际读完所选范围，填写下面的内容，然后运行检查。
python3 tools/novel_library.py --root . study-check --file drafts/开篇拆解.json
```

填写question、observation、interpretation、technique、applicability、failure_conditions和terms。observation记录正文确实发生的事，interpretation记录对读者效果的推断。technique写清可以迁移的安排，applicability和failure_conditions写适用前提与失效情形。read_full_scope只在实际读完声明范围后设为true，decision改为ready。

evidence每项包含chapter、start_line、end_line、sha256、quote。sha256使用read返回的章节哈希，quote取该行段中最短必要引文。工具逐项核对原文、章节、行号和版本。通过后生成study_id，catalog展示已登记阅读范围的并集。阅读声明和文学结论仍由实际审读者负责。

整本教材关注持续吸引读者的主角追求、阻力变化、关系演变和阶段兑现，证据覆盖所讨论的关键转折。阶段教材连接期待、行动、结果及后续影响。场景教材写清双方目标、消息、筹码、可选办法和代价。段落教材研究视角、选取的细节、信息先后和对白里的回避与试探。

## 对照原作练习

根据已读前情设计具体写作问题，例如「主角怎样让曾伤害过她的人帮忙，并让这次求助改变两人关系」。保留当前人物资源和知情边界，先写自己的练习稿并保存，再读取所选后文对照。

```bash
python3 tools/novel_library.py --root . practice-request --book 实际书籍编号 --through 2 --answer-through 3 --question "主角怎样让对方帮忙并承担代价" --out drafts/练习任务.json
python3 tools/novel_library.py --root . practice-save --task drafts/练习任务.json --draft drafts/我的练习.txt
python3 tools/novel_library.py --root . read --book 实际书籍编号 --chapter 3
python3 tools/novel_library.py --root . review-request --attempt 实际练习编号 --out drafts/练习复盘.json
# GPT比较原作与已保存练习，填写具体差距后提交。
python3 tools/novel_library.py --root . review-check --file drafts/练习复盘.json
```

复盘填写draft_choice、author_choice、gap、lesson、applicability、failure_conditions和原作后文evidence。用具体取舍解释差异，例如「我让对手轻易答应，原作让主角先承担对手不愿承担的风险」，再写适用前提和失效情形。原作是强参考，也可以保留其他成立的解法。

feedback_origin按实际来源填写model、author、reader或editor。默认mode为same_context_approximation，limitations如实写已见原作、同一上下文或审读来源的影响。确实单独输入且只给前情时才能标isolated_input。保存顺序核验的是文件流程，不能证明模型没有见过后文。练习属于参考库教材，未来新书单独使用全新人物和事件因果。

## 写新书时调用

先按平台和题材选样本，研究整书及阶段怎样成立，再设计本书自己的欲望、处境、卖点和关键转折。每章确定当前难题，用关系、处境、阶段或预期情绪查已完成教材，并回读匹配证据及前后文。关键词查不到时，选取原文补建教材。

```bash
python3 tools/novel_library.py --root . search --query "弱势主角 求助 交换代价" --platform 七猫 --level scene
python3 tools/novel_library.py --root . export --study 实际教材编号 --review 实际复盘编号 --question "本章怎样让对手自愿让步" --repository-url https://github.com/作者/参考库 --commit 实际40位提交SHA --out drafts/本章教材.json
```

export只导出原创学习结论、适用范围、失败条件和可回查的来源编号与哈希。原文引文保存在参考库。线上来源固定到实际已提交版本，上传前核对分支头，写后回读。新书的project_config.json设置reference_library.repository_url和branch，绑定真实小说库。

在新书工具目录执行原有流程。

```bash
python3 tools/novel_state.py --root book brief-request --references 教材摘要实际路径.json --out drafts/本章任务书.json
# 填原任务书，并填写references.application和references.originality。
python3 tools/novel_state.py --root book brief-check --file drafts/本章任务书.json
python3 tools/novel_state.py --root book context --profile writer --out drafts/写作资料.md
```

application只写本书实际采用的安排，originality写本书人物为何如此行动、如何解题、代价及后果。writer资料使用这两段自然语言。已绑定小说库的项目在登记和读取当前任务书时核对来源仓库、摘要版本和实际用法，教材选择随当前难题调整。

完成正文后，在原发布前报告的actual_scenes、plan_comparison和reader.issues核对所学是否真正落实。若桥段的连续选择、解决办法与代价贴近某个样本，重做当前未冻结稿的因果。照常执行候选、最多三轮修订、到期回看、release-check和冻结。

## 用真实作品检验

首轮集中一个平台和题材，精读少量完整作品，建立几组有原文依据的练习。拿全新题目写完整前三章，与原有方法的稿件隐去来源后交给实际读者比较，记录反馈来源和具体正文位置。新书题目及未见作品用于验收，教学用的原作练习用于诊断。已有六次拒签的实际投稿版本及反馈可作为另一个复盘来源。

训练材料的多少、程序检查和模型自评分别记录。签约效果由实际投稿结果积累验证。原文和分析按任务分批读取，GitHub保存长期记录，当前GPT每次按需读取教材。工具通过不代表当前模型权重已经改变。
